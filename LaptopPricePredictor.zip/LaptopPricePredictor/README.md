# LaptopPricePredictor
Laptop price predictor is a Machine learning based application build on flask server


